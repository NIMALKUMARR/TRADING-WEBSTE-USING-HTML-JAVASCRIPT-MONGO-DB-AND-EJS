const mongoose = require('mongoose');
const trading = require('./trading');
const Schema = mongoose.Schema;
const wishlist =require('./wishlist');
const tradeSchema = new Schema({
    productname: {type: String, required: [true, 'productname is required']},
    category: {type: String, required: [true, 'category is required']},
    posted: {type: Schema.Types.ObjectId, ref: 'User'},
    details: {type: String, required: [true, 'Detail is required'], 
              minLength: [10, 'The detail should have at least 10 characters']},
    brandname: {type: String, required: [true, 'Brand is required']},
    location: {type: String, required: [true, 'Location is required']},
    price: {type: Number, required: [true, 'Price is required']},
    image: {type: String, required: [true, 'Image is required']},
    status: {type: String ,default: "Available"}
},
{timestamps: true}
);

tradeSchema.pre('findOneAndDelete', function(next) {
    let id = this.getQuery()['_id'];
    wishlist.deleteMany({ trade: id}).exec();
    next();
});

//collection name is stories in db
module.exports = mongoose.model('trade', tradeSchema);
