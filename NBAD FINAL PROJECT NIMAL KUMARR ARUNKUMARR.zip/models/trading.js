const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const tradingSchema = new Schema({
    owner:{type: Schema.Types.ObjectId, ref: 'User'},
    product:{type: Schema.Types.ObjectId, ref: 'trade'},
    tradingproduct:{type: Schema.Types.ObjectId, ref: 'trade'}
}
);

module.exports = mongoose.model('Trading', tradingSchema);