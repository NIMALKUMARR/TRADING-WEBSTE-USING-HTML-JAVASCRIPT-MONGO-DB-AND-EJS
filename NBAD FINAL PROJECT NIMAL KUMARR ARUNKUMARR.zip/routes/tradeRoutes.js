const express = require('express');
const {isLoggedIn, isPosted} = require('../middlewares/auth');
const { validateId } = require('../middlewares/validator'); 
const controller = require('../controllers/tradeController');
const { validateTrade, validateResult } = require('../middlewares/validator');
const router = express.Router();

//GET /stories: send all stories to the user

router.get('/', controller.index);

//GET /stories/new: send html form for creating a new story

router.get('/new', isLoggedIn, controller.new);

//POST /stories: create a new story

router.post('/', isLoggedIn, validateTrade, validateResult, controller.create);

//GET /stories/:id: send details of story identified by id
router.get('/:id', validateId, controller.show);

//GET /stories/:id/edit: send html form for editing an exising story
router.get('/:id/edit', validateId, isLoggedIn, isPosted, controller.edit);

//PUT /stories/:id: update the story identified by id
router.put('/:id', validateId, isLoggedIn, isPosted, validateTrade, validateResult, controller.update);

//DELETE /stories/:id, delete the story identified by id
router.delete('/:id', validateId, isLoggedIn, isPosted, controller.delete);

//POST /:id/wishlist: user response to add wishlist
router.post('/:id/wishlist', validateId, isLoggedIn, controller.wishlist);

//DELETE ///:id: delete item from wishlidr by id
router.delete('/wishlist/:id', validateId, isLoggedIn, controller.deletewishlist);

router.post('/:id/trading', validateId, isLoggedIn, controller.trading);

router.post('/:id/acceptRequest', validateId, isLoggedIn, controller.acceptRequest);

router.post('/:id/rejectRequest', validateId, isLoggedIn, controller.rejectRequest);

router.post('/:id/cancelRequest', validateId, isLoggedIn, controller.cancelRequest);

router.post('/:id/manageRequest', validateId, isLoggedIn, controller.manageRequest);

router.post('/:id/tradeRequest',validateId, isLoggedIn, controller.tradeRequest);


module.exports = router;