const model  = require('../models/user');
const trade  = require('../models/trade');
const wishlist =require('../models/wishlist');
const trading = require('../models/trading');
exports.new = (req, res)=>{

    return res.render('./user/new');
};

exports.create = (req, res, next)=>{
     //res.send('Created a new trade');
    let user = new model(req.body);//create a new trade document
user.save()//insert the document to the database
.then(user=> res.redirect('/users/login'))
.catch(err=>{
    if(err.name === 'ValidationError' ) {
        req.flash('error', err.message);  
        return res.redirect('/users/new');
    }

    if(err.code === 11000) {
        req.flash('error', 'Email has been used');  
        return res.redirect('/users/new');
    }
    
    next(err);
}); 


};

exports.getUserLogin = (req, res, next) => {
    return res.render('./user/login');
}

exports.login = (req, res, next)=>{
let email = req.body.email;
let password = req.body.password;
model.findOne({ email: email })
.then(user => {
    if (!user) {
       req.flash('error', 'wrong email address');  
       res.redirect('/users/login');
       } else {
       user.comparePassword(password)
        .then(result=>{
            if(result) {
                req.session.user = user._id;
                req.session.firstName = user.firstName;
                req.session.lastName = user.lastName;
                req.flash('success', 'You have successfully logged in');
                res.redirect('/users/profile');
        } else {
            req.flash('error', 'wrong password');      
            res.redirect('/users/login');
        }
        })
        .catch(err => next(err));
    }     
})
.catch(err => next(err));

};

exports.profile = (req, res, next)=>{
    let id = req.session.user;
    let list1 = []
    let list2 = []
    console.log()
    Promise.all([model.findById(id), trade.find({posted: id}), wishlist.find({user: id}).populate('trade'),trading.find({owner:id}).populate('product')]) 
    .then(results=>{
     const [user, trading, wishlists, requests] = results;
     const flag = false;
     console.log(requests);
     trading.forEach(trade =>{
        
         list1.push(trade.id);
     })
     requests.forEach(trade =>{
         list2.push(trade.tradingproduct);
     })
     for (const l1 of list1){
         for (const l2 of list2){
             if( l1 === l2)
             {
                 flag = true;
             }
         }
     }
     console.log(wishlists)
     res.render('./user/profile', {user, trading, wishlists, requests});
    })
    .catch(err=>next(err));
};


exports.logout = (req, res, next)=>{
req.session.destroy(err=>{
    if(err) 
       return next(err);
   else
        res.redirect('/');  
});

};