
const { DateTime } = require("luxon");
const Trade = require('../models/trade');
const { Model } = require('mongoose');
const wishlist = require('../models/wishlist');
const trading = require('../models/trading');


exports.index = (req, res, next) => {
    //res.send('send all stories');
    let categories = [];
    Trade.distinct("category", function (error, results) {
        categories = results;
    });
    Trade.find()
        .then(trades => res.render('./trade/index', { trades, categories }))
        .catch(err => next(err));
};

exports.new = (req, res) => {
    res.render('./trade/new');
};

exports.create = (req, res, next) => {
    //res.send('Created a (new story');
    let trade = new Trade(req.body);
    trade.posted = req.session.user;
    trade.save()
        .then((trade) => {
            req.flash('success', 'You have successfully posted an item for sale!');
            res.redirect('/trades')
        })
        .catch(err => {
            if (err.name === 'ValidationError') {
                err.status = 400;
            }
            next(err);
        });

};

exports.show = (req, res, next) => {
    let id = req.params.id;
    Trade.findById(id).populate('posted', 'firstName lastName')
        .then(trade => {
            if (trade) {
                wishlist.countDocuments({ status: 'Yes', trade: id })
                    .then(wishlistCount => {
                        return res.render('./trade/show', { trade, wishlistCount });
                    })
                    .catch(err => next(err));
            } else {
                let err = new Error('Cannot find a trade with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));
};

exports.edit = (req, res, next) => {
    let id = req.params.id;
    Trade.findById(id)
        .then(trade => {
            if (trade) {
                res.render('./trade/edit', { trade });
            } else {
                let err = new Error('Cannot find a trade with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err))
};

exports.update = (req, res, next) => {
    let trade = req.body;
    let id = req.params.id;

    Trade.findByIdAndUpdate(id, trade, { useFindAndModify: false, runValidators: true })
        .then(trade => {
            if (trade) {
                res.redirect('/trades/' + id);
            } else {
                let err = new Error('Cannot find a trade with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => {
            if (err.name === 'ValidationError')
                err.status = 400;
            next(err)
        });
};

exports.delete = async (req, res, next) => {
    let id = req.params.id;
    console.log(id);
    let trading1 = await trading.findOne({ $or: [{ product: id }, { tradingproduct: id }] });
    console.log(trading1)
    if (trading1) {
        await Trade.findOneAndUpdate({ _id: trading1.product }, { status: "Available" })

        await Trade.findOneAndUpdate({ _id: trading1.tradingproduct }, { status: "Available" })
        await trading.deleteMany({ $or: [{ product: id }, { tradingproduct: id }] });
    }


    Trade.findOneAndDelete({ _id: id }, { useFindAndModify: false, runValidators: true })
        .then(trade => {
            if (trade) {
                res.redirect('/trades');
            } else {
                let err = new Error('Cannot find a trade with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));

};


exports.wishlist = (req, res, next) => {
    let users = req.session.user;
    let id = req.params.id;
    let status = req.body.status;

    Trade.findById(id)
        .then(trade => {
            if (trade) {
                if (trade.post == users) {
                    let err = new Error('Unauthorized to access the resource');
                    err.status = 401;
                    return next(err);
                } else {
                    wishlist.updateOne({ trade: id, user: users },
                        { $set: { trade: id, user: users, status: status } },
                        { upsert: true })
                        .then(wishlist => {
                            if (wishlist) {
                                if (wishlist.updated) {
                                    req.flash('success', 'Successfully added item to  the wishlist');
                                } else {
                                    req.flash('success', 'Successfully modified item in  the wishlist');
                                }
                                res.redirect('/users/profile');
                            } else {
                                req.flash('error', 'error cannot create a wishlist for this item');
                                res.redirect('back');
                            }
                        })
                        .catch(err => {
                            if (err.name === 'ValidationError') {
                                req.flash('error', err.message);
                                res.redirect('back');
                            } else {
                                next(err);
                            }
                        });
                }
            } else {
                let err = new Error('Cannot find a trade with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));

};

exports.deletewishlist = (req, res, next) => {
    let id = req.params.id;
    wishlist.findByIdAndDelete(id, { useFindAndModify: false })
        .then(wishlist => {
            if (wishlist) {
                req.flash('success', 'wishlist has been sucessfully deleted!');
                res.redirect('/users/profile');
            } else {
                let err = new Error('Cannot find an wishlist with id ' + id);
                err.status = 404;
                return next(err);
            }
        })
        .catch(err => next(err));
};


exports.tradeRequest = (req, res, next) => {
    console.log("tradeRequest")
    let tradingProduct = req.params.id;
    let tradeID = req.body;
    let user = req.session.user;
    let traded = tradeID.trade
    console.log(tradeID);
    trading.findOne({ product: tradingProduct }, { tradingproduct: traded })
        .then(action => {
            if (!action) {
                let nt = new trading();
                nt.owner = user;
                nt.product = tradingProduct;
                nt.tradingproduct = traded
                Trade.findOneAndUpdate({ _id: tradingProduct }, { status: "Offer pending" })
                    .then(result => {
                        Trade.findOneAndUpdate({ _id: traded }, { status: "Offer pending" })
                            .then(res1 => {
                                nt.save();
                                req.flash('success', 'product has been offered succesfully!');
                                res.redirect('/users/profile');
                            })
                            .catch(err => next(err));
                    })
                    .catch(err => next(err));


            }
            else {
                res.redirect('/trades');
            }

        })
        .catch(err => next(err));
}

exports.trading = (req, res, next) => {
    let id = req.params.id;
    let user = req.session.user;
    Promise.all([Trade.findById(user), Trade.find({ posted: user })])
        .then(results => {
            let a = true;
            const [user, trades] = results;
            res.render('./trade/tradeProduct', { user, trades, id })
        })
        .catch(err => next(err));
}


exports.cancelRequest = async (req, res, next) => {
    let id = req.params.id;
    console.log(id);
    let tradingitems = await trading.findOne({ _id: id })
    console.log(tradingitems)
    trading.findOneAndDelete({ _id: id })
        .then(trade => {
            console.log(trade)
            const tradingProduct = trade.tradingproduct
            const Product = trade.product
            Trade.findOneAndUpdate({ _id: tradingProduct }, { status: "Available" })
                .then(trade => {

                })
                .catch(err => next(err));
            Trade.findOneAndUpdate({ _id: Product }, { status: "Available" })
                .then(trade => {
                })
                .catch(err => next(err));

            req.flash('success', 'Offer has been successfully canceled');
            res.redirect('/users/profile');
        })
}

exports.manageRequest = (req, res, next) => {
    let id = req.params.id;
    console.log(id)
    let trade = true
    trading.findOne({ tradingproduct: id }).populate('product').populate('tradingproduct')
        .then(result => {
            if (result) {
                res.render('./trade/manageRequest', { trade, result })
            }
            else {
                trade = false;
                trading.findOne({ product: id }).populate('product').populate('tradingproduct')
                    .then(result => {
                        res.render('./trade/manageRequest', { trade, result })
                    })
                    .catch(err => next(err));

            }
        })
        .catch(err => next(err));
}


exports.rejectRequest = (req, res, next) => {
    let id = req.params.id;
    console.log(id);
    Trade.findByIdAndUpdate(id, { status: "Available" }, { useFindAndModify: false, runValidators: true })
        .then(trade => {
            if (trade) {
                req.flash('success', 'product has been successfully updated');
            } else {
                let err = new Error('Cannot find a product with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));

    trading.findOne({ product: id }).populate('tradingproduct')
        .then(result => {
            const tradingProduct = result.tradingproduct.id
            Trade.findByIdAndUpdate(tradingProduct, { status: "Available" }, { useFindAndModify: false, runValidators: true })
                .then(trade => {
                    if (trade) {
                        req.flash('success', 'product has been successfully updated');
                    } else {
                        let err = new Error('Cannot find a product with id ' + tradingProduct);
                        err.status = 404;
                        next(err);
                    }
                })
                .catch(err => next(err));
            trading.findOneAndDelete({ product: id })
                .then(result => {
                    req.flash('success', 'Offer has been Rejected');
                    res.redirect("/users/profile")
                })
                .catch(err => next(err));
        })
        .catch(err => next(err));

}

exports.acceptRequest = (req, res, next) => {
    let id = req.params.id;


    Trade.findByIdAndUpdate(id, { status: "Traded" }, { useFindAndModify: false, runValidators: true })
        .then(trade => {

              
                trading.findOne({ $or: [{ product: id }, { tradingproduct: id }]}).populate('tradingProduct')
                    .then(result => {
   console.log(result)
                        const tradingProduct = result.tradingproduct
                        console.log(tradingProduct)
                        Trade.findByIdAndUpdate(tradingProduct, { status: "Traded" }, { useFindAndModify: false, runValidators: true })
                            .then(trade => {

                                   
                                    trading.findOneAndDelete({ _id: result._id })
                                        .then(result => {
                                            if (result) {
                                                req.flash('success', 'Offer has been Accepted');
                                                res.redirect("/users/profile")
                                            }
                                        })
                                        .catch(err => next(err));
                            })
                            .catch(err => next(err));


                    })
                    .catch(err => next(err));
        })
        .catch(err => next(err));





}